# Project name

[![](https://jitpack.io/v/ondrej-nemec/lordoffiles.svg)](https://jitpack.io/#ondrej-nemec/--project)
[![MIT License](http://img.shields.io/badge/license-MIT-green.svg) ](https://github.com/ondrej-nemec/--project--/blob/master/LICENSE)

* [Description](#description)
* [Get library](#how-to-install)
* [Usage](#usage)
	

## Description


## How to install
### Download:

<a href="https://ondrej-nemec.github.io/download/--.jar" target=_blank>Download jar</a>

### Maven:
After `build` tag:
```xml
<repositories>
	<repository>
	    <id>jitpack.io</id>
	    <url>https://jitpack.io</url>
	</repository>
</repositories>
```
And to `dependencies`:
```xml
<dependency>
  <groupId>com.github.ondrej-nemec</groupId>
  <artifactId>--</artifactId>
  <version>--</version>
</dependency>
```

## Usage
