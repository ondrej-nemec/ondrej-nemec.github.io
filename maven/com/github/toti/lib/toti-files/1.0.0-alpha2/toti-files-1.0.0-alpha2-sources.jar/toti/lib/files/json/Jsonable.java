package toti.lib.files.json;

import toti.lib.common.functions.Mapper;

public interface Jsonable {

	default Object toJson() {
		return Mapper.get().serialize(this);
	}
	
}
