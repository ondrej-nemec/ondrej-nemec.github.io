package toti.lib.templating.parsing;

public interface Parser {

	/**
	 * 
	 * @return if parsing finished
	 */
	boolean accept(char previous, char actual, boolean isSingleQuoted, boolean isDoubleQuoted);
	
}
