package toti.lib.templating;

public class TemplateException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public TemplateException(String message) {
		super(message);
	}
	
}
