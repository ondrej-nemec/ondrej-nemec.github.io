package toti.lib.templating.tags;

import java.util.Map;

import toti.lib.templating.Tag;
import toti.lib.templating.TagVariableMode;
import toti.lib.templating.TemplateException;

public class IncludeTag implements Tag {
	
	@Override
	public TagVariableMode getMode(String name) {
		switch (name) {
			case "file":
			case "block":
			case "optional":
			case "module":
				return TagVariableMode.STRING;
			default:
				return TagVariableMode.CODE;
		}
	}
	
	@Override
	public String getName() {
		return "include";
	}

	@Override
	public String getPairStartCode(Map<String, String> params) {
		return getNotPairCode(params);
	}

	@Override
	public String getPairEndCode(Map<String, String> params) {
		return "";
	}

	@Override
	public String getNotPairCode(Map<String, String> params) {
		if (!params.containsKey("block") && !params.containsKey("file")) {
			throw new TemplateException("Tag 'include' has to contains parameter 'block' or 'file'");
		}
		if (params.get("block") != null) {
			StringBuilder code = new StringBuilder();
			code.append(String.format(
				"getBlock(\"%s\",%s)", 
				params.get("block"),
				params.get("optional") == null ? "true" : "false"
			));
			code.append(".accept(new MapInit<String, Object>()");
			params.forEach((name, value)->{
				if (!name.equals("block") && !name.equals("optional")) {
					code.append(String.format(".append(\"%s\", %s)", name, value.isEmpty() ? '"' + '"' : value));
				}
			});
			code.append(".toMap());");
			return code.toString();
		}
		StringBuilder code = new StringBuilder("{");
		code.append("initNode(new MapInit<String, Object>()");
		params.forEach((name, value)->{
			if (!name.equals("file") && !name.equals("module")) {
				code.append(String.format(".append(\"%s\", %s)", name, value.isEmpty() ? '"' + '"' : value));
			}
		});
		code.append(".toMap());");
		if (params.get("module") == null) {
			code.append(String.format("Template temp = templateFactory.getTemplate(moduleName, \"%s\");", params.get("file")));
		} else {
			code.append(String.format(
					"Template temp = templateFactory.getTemplate(\"%s\", \"%s\");",
					params.get("module"), params.get("file")
			));
		}
		code.append("temp._create(variables,this.nodes,this.hashCode());");
		code.append("flushNode();");
		code.append("}");
		return code.toString();
	}

}
