package toti.core;

import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;

import toti.core.answers.Answer;
import toti.core.answers.router.Link;
import toti.core.application.Task;
import toti.core.application.register.MappedAction;
import toti.core.application.register.Param;
import toti.core.application.register.Register;
import toti.core.extensions.Extension;
import toti.lib.tcpip.enums.HttpMethod;

public class Application {
	
	private final List<Task> tasks;
	
	private final Link link;
	private final Register register;
	private final Answer answer;
	
	private final boolean autoStart;
	private boolean isRunning = false;
	private final Param root;
	
	private final String basePath;
	private final String hostname;
	
	private final Collection<Extension> extensions;
	
	public Application(
			List<Task> tasks, Param root,
			Link link, Register register, Collection<Extension> appExtensions, Answer answer,
			boolean autoStart, String hostname, String basePath) {
		this.tasks = tasks;
		this.link = link;
		this.register = register;
		this.answer = answer;
		this.autoStart = autoStart;
		this.hostname = hostname;
		this.root = root;
		this.basePath = basePath;
		this.extensions = appExtensions;
	}

	public String getBasePath() {
		return basePath;
	}
	
	public String getHostname() {
		return hostname;
	}

	public Link getLink() {
		return link;
	}

	public Register getRegister() {
		return register;
	}

	protected Answer getRequestAnswer() {
		return answer;
	}

	public boolean isAutoStart() {
		return autoStart;
	}
	
	public boolean isRunning() {
		return isRunning;
	}

	/************/

	public boolean start() throws Exception {
		if (isRunning) {
			return false;
		}
		for (Extension extension : extensions) {
			extension.onApplicationStart();
		}
		for (Task task : tasks) {
			task.start();
		}
		isRunning = true;
		return true;
	}
	
	public void stop() throws Exception {
		isRunning = false;
		for (Task task : tasks) {
			task.stop();
		}
		for (Extension extension : extensions) {
			extension.onApplicationStop();
		}
	}
	
	/****************/
	
	public void iterate(Consumer<Item> onItem) {
		iterate(onItem, root, "", 0);
	}

	private void iterate(Consumer<Item> onItem, Param param, String uri, int deep) {
		String path = getPath(uri, param);
		param.getActions().forEach((method, action)->{
			 onItem.accept(new Item(path, method, action));
		});

		param.getChilds().forEach((x, child)->{
			 iterate(
				 onItem,
				 child,
				 deep == 0 ? uri : path,
				 deep+1
			 );
		});
	}
	
	private String getPath(String uri, Param param) {
		if (param.getText() != null) {
			return uri + "/" + param.getText();
		}
		return uri + "/{}";
	}

	public class Item {

		private final String uri;
		private final HttpMethod method;
		private final MappedAction action;
		
		public Item(String uri, HttpMethod method, MappedAction action) {
			 this.uri = uri;
			 this.method = method;
			 this.action = action;
		}

		public MappedAction getAction() {
			 return action;
		}

		public HttpMethod getMethod() {
			 return method;
		}

		public String getUri() {
			 return uri;
		}
	}
}
