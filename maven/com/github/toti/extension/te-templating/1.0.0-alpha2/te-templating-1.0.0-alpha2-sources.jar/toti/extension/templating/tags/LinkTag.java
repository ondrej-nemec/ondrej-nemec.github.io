package toti.extension.templating.tags;

import java.util.Map;

import toti.core.answers.router.Link;
import toti.extension.templating.TemplateExtension;
import toti.lib.common.exceptions.LogicException;
import toti.lib.templating.Tag;
import toti.lib.templating.TagVariableMode;

public class LinkTag implements Tag {
	
	@Override
	public TagVariableMode getMode(String name) {
		return TagVariableMode.STRING;
	}

	@Override
	public String getName() {
		return "link";
	}

	@Override
	public String getPairStartCode(Map<String, String> params) {
		return getNotPairCode(params);
	}

	@Override
	public String getPairEndCode(Map<String, String> params) {
		return "";
	}

	@Override
	public String getNotPairCode(Map<String, String> params) {
		String controller = params.remove("controller");
		if (params.get("method") == null || params.get("method").isEmpty()) {
			 throw new LogicException("LinkTag: 'method' parameter is required and must be non-empty");
		}
		String[] function = params.remove("method").split(":");
		String method = function[0];
		
		StringBuilder result = new StringBuilder(String.format(
			Link.class.getCanonicalName()
			+ ".class.cast(getVariable(\"%s\"))"
			+ ".create(\"%s\", \"%s\", MapInit.create()", TemplateExtension.VARIABLE_NAME_LINK, controller, method
		));
		
		params.forEach((name, value)->{
			result.append(String.format(".append(\"%s\",\"%s\")", name, value));
		});
		result.append(".toMap()");
		for (int i = 1; i < function.length; i++) {
			result.append(String.format(",\"%s\"", function[i]));
		}
		result.append(")");
		return "write(" + result.toString() + ");";
	}

}
